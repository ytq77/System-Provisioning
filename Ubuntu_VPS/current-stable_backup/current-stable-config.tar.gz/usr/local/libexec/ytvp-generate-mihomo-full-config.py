#!/usr/bin/env python3
"""Translate the subset of SubConverter INI used by this deployment to Mihomo YAML."""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import OrderedDict
from pathlib import Path
from urllib.parse import urlparse


RESERVED_POLICIES = {
    "DIRECT",
    "REJECT",
    "REJECT-DROP",
    "PASS",
    "COMPATIBLE",
}


def yaml_quote(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def provider_slug(url: str, used: set[str]) -> str:
    stem = Path(urlparse(url).path).stem.lower()
    slug = re.sub(r"[^a-z0-9]+", "-", stem).strip("-") or "remote-rules"
    candidate = slug
    suffix = 2
    while candidate in used:
        candidate = f"{slug}-{suffix}"
        suffix += 1
    used.add(candidate)
    return candidate


def read_ini(path: Path) -> tuple[list[tuple[str, str, str]], list[dict[str, object]]]:
    rules: list[tuple[str, str, str]] = []
    groups: list[dict[str, object]] = []
    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        line = raw_line.strip()
        if not line or line.startswith((";", "#", "[")):
            continue
        if line.startswith("ruleset="):
            payload = line[len("ruleset=") :]
            if "," not in payload:
                raise ValueError(f"{path}:{line_number}: malformed ruleset")
            policy, spec = payload.split(",", 1)
            rules.append((policy.strip(), spec.strip(), str(line_number)))
        elif line.startswith("custom_proxy_group="):
            payload = line[len("custom_proxy_group=") :]
            parts = payload.split("`")
            if len(parts) < 3:
                raise ValueError(f"{path}:{line_number}: malformed proxy group")
            group_name, group_type = parts[0].strip(), parts[1].strip()
            if group_type != "select":
                raise ValueError(f"{path}:{line_number}: unsupported group type {group_type}")
            groups.append(
                {
                    "name": group_name,
                    "type": group_type,
                    "members": [part.strip() for part in parts[2:] if part.strip()],
                    "line": line_number,
                }
            )
    if not rules or not groups:
        raise ValueError(f"{path}: no rules or groups found")
    return rules, groups


def read_nodes(path: Path, expected_nodes: int) -> tuple[str, list[str]]:
    text = path.read_text(encoding="utf-8-sig")
    if not re.search(r"(?m)^proxies:\s*$", text):
        raise ValueError(f"{path}: expected a top-level proxies key")
    extra_keys = re.findall(r"(?m)^([A-Za-z0-9_-]+):\s*$", text)
    if extra_keys != ["proxies"]:
        raise ValueError(f"{path}: expected a node-only provider, got keys {extra_keys}")
    names = re.findall(r"(?m)^\s{2}- name:\s*(.+?)\s*$", text)
    names = [name.strip().strip('"\'') for name in names]
    if len(names) != expected_nodes:
        raise ValueError(f"{path}: expected {expected_nodes} nodes, got {len(names)}")
    if len(set(names)) != len(names):
        raise ValueError(f"{path}: duplicate node names")
    return text.rstrip() + "\n", names


def translate(
    ini_path: Path,
    nodes_path: Path,
    output_path: Path,
    source_label: str,
    expected_nodes: int,
) -> dict[str, int]:
    raw_rules, raw_groups = read_ini(ini_path)
    nodes_text, node_names = read_nodes(nodes_path, expected_nodes)

    provider_used: set[str] = set()
    providers: OrderedDict[str, dict[str, object]] = OrderedDict()
    translated_rules: list[str] = []

    for policy, spec, line_number in raw_rules:
        if spec.startswith("[]GEOSITE,"):
            category = spec[len("[]GEOSITE,") :].strip()
            translated_rules.append(f"GEOSITE,{category},{policy}")
            continue
        if spec.startswith("[]GEOIP,"):
            fields = [field.strip() for field in spec[len("[]GEOIP,") :].split(",")]
            if len(fields) not in (1, 2) or (len(fields) == 2 and fields[1] != "no-resolve"):
                raise ValueError(f"{ini_path}:{line_number}: malformed GEOIP rule")
            translated_rules.append(
                ",".join(["GEOIP", fields[0], policy] + (["no-resolve"] if len(fields) == 2 else []))
            )
            continue
        if spec == "[]FINAL":
            translated_rules.append(f"MATCH,{policy}")
            continue

        match = re.fullmatch(r"clash-(classic|domain):(.+),(\d+)", spec)
        if not match:
            raise ValueError(f"{ini_path}:{line_number}: unsupported ruleset spec {spec}")
        source_type, url, interval_text = match.groups()
        behavior = "classical" if source_type == "classic" else "domain"
        existing = next(
            (
                name
                for name, data in providers.items()
                if data["url"] == url and data["behavior"] == behavior
            ),
            None,
        )
        provider_name = existing or provider_slug(url, provider_used)
        if existing is None:
            providers[provider_name] = {
                "behavior": behavior,
                "url": url,
                "interval": int(interval_text),
            }
        translated_rules.append(f"RULE-SET,{provider_name},{policy}")

    translated_groups: list[dict[str, object]] = []
    for raw_group in raw_groups:
        members: list[str] = []
        for member_spec in raw_group["members"]:
            assert isinstance(member_spec, str)
            if member_spec.startswith("[]"):
                members.append(member_spec[2:])
                continue
            if member_spec.startswith("(") and member_spec.endswith(")"):
                pattern = re.compile(member_spec)
                matches = [node_name for node_name in node_names if pattern.search(node_name)]
                if not matches:
                    raise ValueError(
                        f"{ini_path}:{raw_group['line']}: node filter {member_spec} matched nothing"
                    )
                members.extend(matches)
                continue
            raise ValueError(
                f"{ini_path}:{raw_group['line']}: unsupported group member {member_spec}"
            )
        translated_groups.append(
            {"name": raw_group["name"], "type": raw_group["type"], "members": members}
        )

    group_names = [str(group["name"]) for group in translated_groups]
    if len(set(group_names)) != len(group_names):
        raise ValueError(f"{ini_path}: duplicate proxy group names")
    available = set(node_names) | set(group_names) | RESERVED_POLICIES
    for group in translated_groups:
        for member in group["members"]:
            if member not in available:
                raise ValueError(f"{ini_path}: group {group['name']} references undefined {member}")
    for rule in translated_rules:
        fields = rule.split(",")
        policy = fields[-2] if fields[-1] == "no-resolve" else fields[-1]
        if policy not in available:
            raise ValueError(f"{ini_path}: rule references undefined policy {policy}")
        if fields[0] == "RULE-SET" and fields[1] not in providers:
            raise ValueError(f"{ini_path}: rule references undefined provider {fields[1]}")
    if not translated_rules[-1].startswith("MATCH,"):
        raise ValueError(f"{ini_path}: final rule is not MATCH")
    if any(rule.startswith("MATCH,") for rule in translated_rules[:-1]):
        raise ValueError(f"{ini_path}: MATCH appears before final rule")

    out: list[str] = [
        "# Generated from " + source_label + "; edit the INI source, not this file.",
        "# Listener, DNS and TUN settings remain managed by the client application.",
        "mode: rule",
        "",
        nodes_text.rstrip(),
        "",
        "proxy-groups:",
    ]
    for group in translated_groups:
        out.extend(
            [
                f"  - name: {yaml_quote(str(group['name']))}",
                f"    type: {group['type']}",
                "    proxies:",
            ]
        )
        out.extend(f"      - {yaml_quote(str(member))}" for member in group["members"])

    out.extend(["", "rule-providers:"])
    for name, provider in providers.items():
        out.extend(
            [
                f"  {name}:",
                "    type: http",
                f"    behavior: {provider['behavior']}",
                "    format: yaml",
                f"    url: {yaml_quote(str(provider['url']))}",
                f"    path: {yaml_quote('./rule-providers/' + name + '.yaml')}",
                f"    interval: {provider['interval']}",
                f"    proxy: {yaml_quote('⛩️ 日本VPS')}",
            ]
        )

    out.extend(["", "rules:"])
    out.extend(f"  - {yaml_quote(rule)}" for rule in translated_rules)
    out.append("")
    output_path.write_text("\n".join(out), encoding="utf-8", newline="\n")

    return {
        "nodes": len(node_names),
        "groups": len(translated_groups),
        "providers": len(providers),
        "rules": len(translated_rules),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ini", required=True, type=Path)
    parser.add_argument("--nodes", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--source-label", required=True)
    parser.add_argument("--expected-nodes", type=int, default=4)
    args = parser.parse_args()
    summary = translate(
        args.ini,
        args.nodes,
        args.output,
        args.source_label,
        args.expected_nodes,
    )
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
